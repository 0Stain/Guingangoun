#!/bin/bash

fonc1yad(){
  echo "Liste des processus en cours d'execution :"
  ps -A
}

fonc2yad(){
  kill -0 $2 2> /dev/null #tester si le PID existe : 0 si le PID existe , 1 sinon (ERREUR)
  if [ $? -eq 0 ]; then #tester s'il y avait un erreur lors de la recherche du PID
  echo "Le processus " `ps -p $2 -o comm=` "dont le PID est " $2 " :" #la commande "ps -p $2 -o comm" retourne le nom du processus relatif a son PID
  ps -p $2 #affichage du processus dont PID est le 2eme parametre
  else
  echo "Ce PID ne correspond au aucun processus" #le PID tap� n'existe pas
  fi
}

fonc3yad(){
  echo "-> Les informations concernant le processeur :"
  cat /proc/cpuinfo #Affichage des informations concernant le processeur
  echo "-------------------------------------------------------------------------"
  echo "-> Le nombre du core(s) du processeur est :"
  cat /proc/cpuinfo | grep processor | wc -l #Affichage des nombres du cores du processeur
}

fonc4yad(){
  yad --title="help"  --text="
  -------------------------------MENU HELP---------------------------------
  -> Tapez l’option -lp pour lister les processus en cours d’exécution
  -> Tapez l’option -s pid pour afficher l’état d’un processus dont le pid est en second arguement
  -> Tapez l’option -lcpu pour afficher les informations en relation avec le cpu
  -> Tapez l’option -h ou –help pour afficher le help
  -> Tapez l'option '--save' pour sauvegarder les informations dans un fichier.txt(save.txt)
  -> Lancez ce script sans parametres pour afficher les informations les plus importantes concernant le processeur et les processus
  -------------------------------------------------------------------------"
}
fonc5yad(){
  yad --text="saved" --center
  echo "Creation d'un fichier texte en cours ..."
  echo "-> Liste des processus en cours d'execution :" > save.txt
  ps -A >> save.txt
  echo "" >> save.txt
  echo "-> Les informations concernant le processeur :" >>save.txt
  cat /proc/cpuinfo >> save.txt
  echo "" >> save.txt
  echo "-> Le nombre du core(s) du processeur est :" >> save.txt
  cat /proc/cpuinfo | grep processor | wc -l >> save.txt
}
