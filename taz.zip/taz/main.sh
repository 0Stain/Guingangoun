#!/bin/bash

source yad.sh
source fnc.sh

while true
do
echo "Bienvenue voulez vous travaillez avec interface
ou ligne du commande
tapez 1:ligne du commande
      2:interface graphique"
read INPUT_STRING
case $INPUT_STRING in

1)
terminalox
;;
2)
yadox
;;
*)
echo "Error"
;;
esac

done
