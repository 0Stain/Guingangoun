#!/bin/bash
source fonc-terminal.sh

terminalox(){

while true
do
echo "    "
echo  "                 Bienvenue      "
echo ""
echo "-lp"
echo "-s"
echo "-lcpu"
echo " -h ou -help"
echo "--save"
echo "exit"
echo""

echo "saisir votre choix "
read INPUT_STRING
case $INPUT_STRING in

-lp)
    fonc1
;;
-s)
    fonc2
;;
-lcpu)
    fonc3
;;
-h)
    fonc4
;;
-help)
    fonc4
;;
--save)
echo "donner le nom de fichier"
read fichier
    fonc5
;;

exit)
exit
;;

*)
echo "error"
;;

esac
done

}
