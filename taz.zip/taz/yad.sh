#!/bin/bash
source fonc-yad.sh

yadox(){
files=$(yad --width 100 --height 100 --title "Projet 7" \
    --text="  Option ?" \
    --button="-lp:2" \
    --button="-s:3" \
    --button="-lcpu:4" \
    --button="-help:5" \
    --button="--save:6" \
    --button="EXIT:1" \
    --on-top \
    --center \
)

ret=$?
[[ $ret -eq 1 ]] && exit 0

if [[ $ret -eq 2 ]]; then
    fonc4yad
elif [[ $ret -eq 3 ]]; then
    fonc4yad
elif [[ $ret -eq 4 ]]; then
    fonc4yad
elif [[ $ret -eq 5 ]]; then
        fonc4yad
elif [[ $ret -eq 6 ]]; then
      fonc5yad
fi



}
