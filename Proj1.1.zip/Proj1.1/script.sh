#!/bin/bash

. functions.sh

until [ "$a" = "-q" ]
do
echo
echo
echo "		    --------------------Menu--------------------"
echo "			   Veuillez choisir une option:"
echo "		-inside <nom du package>: Afficher le nom d'un package"
echo "		-list  <nom du package>: Lister les composant d'un package"
echo "		-desc <nom du packages>: Afficher la description d'un package"
echo "		-save : enregistrer les noms des packages installes: "
echo "		-h ou -help : afficher le help "
echo "				-q : QUITTER"
echo
echo
read a b

if [ "$a" = "-inside" ] 
then
	inside

elif [ "$a" = "-list" ]
then
	list

elif [ "$a" = "-desc" ]
then
	description

elif [ "$a" = "-save" ]
then
	save

elif [ "$a" = "-h" ]
then
	help

elif [ "$a" = "-help" ]
then
	help

elif [ "$a" = "-q" ]
then
	echo "                 --------------------Au Revoir--------------------"

else
	echo "Veuillez vous assurer que vous avez bien saisie les données."
fi
echo
echo 
echo


done
