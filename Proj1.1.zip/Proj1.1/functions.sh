#!/bin/bash


inside()
{
		echo "Veuillez entrer le nom du package :"
	read pckg
		apt list |grep "$pckg"
	


}

list()
{

	echo "Veuillez entrer le nom du package :"
	read pckg
		 dpkg -S "$pckg"
	


}

description()
{

	echo "Veuillez entrer le nom du package :"
	read pckg
		apt-cache show "$pckg"
	


}

save()
{

	dpkg --get-selections | grep -v deinstall > packages_distribution_date.txt
echo "Tous les packages installés sont enregistrés dans le document packages_distribution_date.txt"
}

hellp()
{

 echo
 echo
 echo "Voici les commandes possibles :"
 echo "-inside pour af"
 echo "-list <nom package> ; lister les composants du package spécifié"
 echo "-desc <nom package> ; description du packagespecifié"
 echo "-save ; sauvegarder les noms des packages installés dans un fichier"

}
save2()
{
ddd=$(date +'-%m-%d-%Y')
  var=$newfile$ddd.txt
dpkg --get-selections | grep -v deinstall > $var
}


