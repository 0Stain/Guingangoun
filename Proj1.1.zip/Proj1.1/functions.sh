#!/bin/bash


inside()
{
 	if [ -z "$b" ]
	then
		echo "Veuillez vous assurer d'entrer le nom du package (-inside <nom package>)"
	else
		apt list |grep "$b"
	fi


}

list()
{
if [ -z "$b" ]
	then
	echo "Veuillez vous assurer d'avoir entré le nom du package (-list <nom package>)"
	else
		 dpkg -S "$b"
	fi


}

description()
{
if [ -z "$b" ]
	then
		echo "Veuillez vous assurer d'avoir entré le nom du package (-desc <nom package>)"
	else
		apt-cache show "$b"
	fi


}

save()
{

	dpkg --get-selections | grep -v deinstall > packages_distribution_date.txt
echo "Tous les packages installés sont enregistrés dans le document packages_distribution_date.txt"
}

help()
{

 echo
 echo
 echo "Voici les commandes possibles :"
 echo "-inside pour af"
 echo "-list <nom package> ; lister les composants du package spécifié"
 echo "-desc <nom package> ; description du packagespecifié"
 echo "-save ; sauvegarder les noms des packages installés dans un fichier"

}


