#!/bin/bash

. functions.sh
echo
echo
echo
echo "1)Afficher le nom d'un package"
echo "2)Lister les composant d'un package"
echo "3)Afficher la description d'un package"
echo "4)Enregistrer les noms des packages installes"
echo "5)Help"




done
