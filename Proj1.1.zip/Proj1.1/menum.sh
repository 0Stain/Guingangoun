#!/bin/bash

source ~/Desktop/Proj1.1/functions.sh

while true
do
echo
echo
echo "0) Quitter"
echo "1)Afficher le nom d'un package"
echo "2)Lister les composant d'un package"
echo "3)Afficher la description d'un package"
echo "4)Enregistrer les noms des packages installes"
echo "5)Enregistrer les informations"
echo "6)Help"
echo "	Veuillez saisir votre choix :"
echo
echo
read INPUT_STRING
case $INPUT_STRING in
0)
    exit
;;
1)
    inside
;;
2)
    list
;;
3)
    description
;;
4)
    save
;;
5)
echo "Veuillez saisir le nom du fichier à creer"
read newfile
	save2
;;
6)
    hellp
;;



*)
echo "Veuillez choisir une des options données"
;;

esac
done

