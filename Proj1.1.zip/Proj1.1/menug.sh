#!/bin/bash
source functionsyad.sh


files=$(yad --width 100 --height 100 --title "Projet 7" \
    --text="  Veuillez choisir une option " \
    --button="-inside:2" \
    --button="-list:3" \
    --button="-description:4" \
    --button="-save:5" \
    --button="-Enregistrer avec la date:6" \
    --button="-Help:7" \
    --button="Quitter:1" \
    --on-top \
    --center \
)

ret=$?
[[ $ret -eq 1 ]] && exit 0

if [[ $ret -eq 2 ]]; then
    yinside
elif [[ $ret -eq 3 ]]; then
    ylist
elif [[ $ret -eq 4 ]]; then
    ydescription
elif [[ $ret -eq 5 ]]; then
        ysave
elif [[ $ret -eq 6 ]]; then
	echo"V
	read newfile      
	ysave2
elif [[ $ret -eq 7 ]]; then
      yhellp
fi




